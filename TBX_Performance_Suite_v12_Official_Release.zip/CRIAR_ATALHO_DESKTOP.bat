@echo off
powershell -NoProfile -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\TBX Studio v12.lnk');$s.TargetPath='%~dp0TBX_Studio_Desktop\dist\tbx_studio_desktop.exe';$s.WorkingDirectory='%~dp0';$s.Save()"
echo Atalho 'TBX Studio v12' criado na Area de Trabalho com sucesso!
pause
