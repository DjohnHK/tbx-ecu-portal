@echo off
title TBX Studio v12.0 — Host Nativo USB-CDC & Wi-Fi Cockpit
start "" "%~dp0TBX_Studio_Desktop\dist\tbx_studio_desktop.exe"
