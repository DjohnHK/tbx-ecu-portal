# Guia Rápido de Oficina — 12 Receitas Prontas de Motores Brasileiros (`.tbxmap`)

Todos os 12 arquivos `.tbxmap` abaixo já vêm calibrados com mapas base de Eficiência Volumétrica (`VE`), Pulso (`ms`), Ponto de Ignição, Alvo de Sonda Lambda (`E100`/`Gasolina`), Roda Fônica, Ordem de Explosão e Dwell seguro de bobinas, além de selo de integridade `TBX Fortress™`:

| Arquivo `.tbxmap` | Motor / Aplicação | Central Recomendada | Ordem de Ignição | Roda Fônica | Dwell 14V |
| :--- | :--- | :---: | :---: | :--- | :---: |
| `VW_AP_20_Turbo_VirtualCam_720_E100.tbxmap` | VW AP 2.0 8V Turbo • 60-2 + VirtualCam™ 720° • E100 | `TBX-400 Universal` | `1-3-4-2` | `Bosch 60-2 (VR/Hall)` | `3.2 ms` |
| `VW_Audi_Golf_18T_20V_Stage3_E100.tbxmap` | VW/Audi Golf GTI & A3 1.8T 20V • 60-2 + Fase • E100 | `TBX-800 PRO` | `1-3-4-2` | `Bosch 60-2 + Hall 1X` | `3.1 ms` |
| `GM_Familia_II_20_8V_Astra_Vectra_Chevette_Turbo_E100.tbxmap` | GM Família II 2.0 8V (Astra/Vectra/Chevette Swap) • 60-2 • E100 | `TBX-400 Universal` | `1-3-4-2` | `GM 60-2 Virabrequim` | `3.4 ms` |
| `GM_Opala_41_6Cil_60_2_E100.tbxmap` | GM Opala / Caravan 4.1 250-S 6 Cil • 60-2 + Bobinas G6 • E100 | `TBX-400 Universal` | `1-5-3-6-2-4` | `Roda 60-2 Polia Damper` | `3.3 ms` |
| `GM_V8_LS_62_58X_Sequencial.tbxmap` | GM V8 LS3 6.2 • 58X + 4X Sequencial 8×8 + DBW • Gasolina | `TBX-800 PRO` | `1-8-7-2-6-5-4-3` | `GM LS 58X (60-2) + 4X` | `3.0 ms` |
| `Honda_Civic_K20_K24_iVTEC_Turbo_E100.tbxmap` | Honda Civic Si K20/K24 i-VTEC Turbo • VTC + E100 | `TBX-800 PRO` | `1-3-4-2` | `Honda K20 12+1 + Cam 4+1` | `2.7 ms` |
| `Honda_Civic_D16_B16_VTEC_Turbo_E100.tbxmap` | Honda Civic D16Y8 / B16A VTEC Turbo • 36-1 / 24-1 • E100 | `TBX-400 Universal` | `1-3-4-2` | `Polia 36-1 Hall / Distrib.` | `2.8 ms` |
| `Fiat_Marea_20_24_20V_5Cil_Turbo_E100.tbxmap` | Fiat Marea 2.0 / 2.4 20V 5 Cilindros Turbo • 60-2 + Fase • E100 | `TBX-800 PRO` | `1-2-4-5-3` | `Bosch 60-2 + Fase Comando` | `3.1 ms` |
| `Fiat_Fire_14_TJet_16V_Turbo_E100.tbxmap` | Fiat Uno / Palio / Punto 1.4 Fire & T-Jet Turbo • 60-2 • E100 | `TBX-400 Universal` | `1-3-4-2` | `Fiat 60-2 Roda Fônica` | `3.0 ms` |
| `VW_EA111_Gol_Saveiro_G5_16_8V_Turbo_E100.tbxmap` | VW EA111 1.6 8V (Gol/Saveiro G5/Fox) Turbo • 60-2 • E100 | `TBX-400 Universal` | `1-3-4-2` | `VW 60-2 Retentor Traseiro` | `3.2 ms` |
| `VW_Fusca_Kombi_Boxer_1600_1900_36_1_E100.tbxmap` | VW Boxer Ar 1600/1900 Injetado / Turbo • 36-1 Centelha Perdida • E100 | `TBX-400 Universal` | `1-4-3-2` | `Roda 36-1 Polia Virabrequim` | `3.3 ms` |
| `Subaru_WRX_EJ20_EJ25_Boxer_Turbo_AVCS.tbxmap` | Subaru Impreza WRX/STI EJ20/EJ25 Turbo • 36-2-2-2 + AVCS | `TBX-800 PRO` | `1-3-2-4` | `Subaru 36-2-2-2 + Cam` | `2.9 ms` |
